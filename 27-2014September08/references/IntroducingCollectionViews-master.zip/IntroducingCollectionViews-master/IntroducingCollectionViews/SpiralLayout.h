#import <UIKit/UIKit.h>

@interface SpiralLayout : UICollectionViewLayout

@end
